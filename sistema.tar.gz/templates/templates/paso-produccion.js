module.exports = (data) => {
    return data.data.mensaje
}
